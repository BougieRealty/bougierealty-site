# How to Edit (No Code)

> Last updated: 2025-09-02

## 1) Upload this folder to GitHub (you’re already on it)
- In your new repo, click **Add file → Upload files** and drag **all files/folders** here.
- Click **Commit changes**.

## 2) Connect Netlify
- Netlify Dashboard → **Add new site → Import an existing project** → pick GitHub → select this repo.
- Build settings:
  - **Build command:** _leave blank_
  - **Publish directory:** `/`
- Click **Deploy site**.

## 3) Enable Identity + Git Gateway
- Netlify → **Identity** → **Enable Identity**.
- Registration: **Invite only**. Invite your email.
- Identity → **Services** → **Enable Git Gateway** (authorize GitHub).

## 4) Log in to your editor
- Go to `https://YOUR-DOMAIN/admin`
- Log in with the invite.
- Collections available:
  - **Partials (Nav & Footer)** → edit `partials/header.html` and `partials/footer.html`
  - **Pages** → edit page HTML (Home, Services, Sellers, Testimonials)
  - **Blog** → create/edit posts

## 5) Edit, then Publish
- Make changes in the editor → **Publish**.
- Netlify will commit to GitHub and auto‑deploy.
- Your site remains **static** (fast, crawlable, AI‑readable).

## Troubleshooting
- If `/admin` asks for login but fails: ensure **Identity** is enabled and you accepted the invite.
- If publishing fails: ensure **Git Gateway** is enabled and authorized.
- If nav/footer don’t change: edit the **partials**, not individual pages.

