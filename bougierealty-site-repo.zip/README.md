# BougieRealty.com

Static site optimized for speed, SEO, and AI readability.  
Includes a visual editor via **Decap (Netlify) CMS** at `/admin`.

## Contents
- `admin/` – CMS app and config (`config.yml`)
- `partials/` – reusable `header.html` and `footer.html` (site‑wide)
- `blog/` – blog index and posts
- `sellers/` – Sellers page (address request form)
- Standard pages: `index.html`, `services.html`, `faq`, `contact`, etc.

## Deploy
Use Netlify **New site from Git** → Build command: _none_ → Publish directory: `/`.

See **HOW_TO_EDIT.md** for step‑by‑step setup and editing.
